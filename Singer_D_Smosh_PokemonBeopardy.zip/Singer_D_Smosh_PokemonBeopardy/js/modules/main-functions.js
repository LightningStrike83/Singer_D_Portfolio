export function mainFunctions() {
    const categoryTitles = document.querySelectorAll(".category-title-con")
    const questionCon = document.querySelectorAll(".question-text-con")
    const answerCon = document.querySelectorAll(".answer-text-con")
    const zoomCon = document.querySelector("#question-zoom-con")
    const answerzoonCon = document.querySelector("#answer-zoom-con")
    const nameSubmit = document.querySelectorAll(".name-submit")
    const closeButton = document.querySelectorAll(".close-button")
    const pointButtons = document.querySelectorAll(".point-button")
    const infoIcons = document.querySelectorAll(".info-icon")

    function nameChange() {
        const parentCheck = this.parentNode 
        const nameValueCheck = parentCheck.querySelector(".name-value")
        const nameValue = nameValueCheck.value
        const dataCheck = parentCheck.dataset.player
        const nameTextCheck = document.querySelector(`#player-${dataCheck}`)
        const name = nameTextCheck.querySelector(".player-name")

        name.textContent = nameValue
        nameValueCheck.value = ""
    }

    function changePoints() {
        const parentNode = this.parentNode.parentNode
        const key = parentNode.dataset.player
        const connectedPlayer = document.querySelector(`#player-${key}`)
        let v = this.value
        let amount = connectedPlayer.querySelector(".point-amount")
        let oldAmount = parseFloat(amount.textContent)
        let factor = parseFloat(v)
        let newAmount = oldAmount + factor

        console.log(key)

        amount.textContent = newAmount
    }

    function revealCategory() {
        const title = this.querySelector(".category-title")

        title.style.display = "flex"
    }

    function revealQuestion() {
        const value = this.querySelector(".value")
        const question = this.querySelector(".question-text")
        const bigQuestion = document.querySelector("#big-question-text")
        const bigAnswer = document.querySelector("#big-answer-text")
        const answer = this.querySelector(".question-answer")
        const dd = this.dataset.dailydouble
        const dailyDouble = document.querySelector("#daily-double-con")

        console.log(question.innerHTML)
        
        value.style.display = "none"

        bigQuestion.innerHTML = question.innerHTML
        bigAnswer.innerHTML = answer.innerHTML

        zoomCon.style.display = "grid"
        answerzoonCon.style.display = "grid"

        answer.style.display = "none"

        gsap.to(window, {duration: 0.5, scrollTo:{y:0}})
    }

    function closeZoomCon() {
        this.parentNode.parentNode.style.display = "none"
    }

    function openExplanation() {
        const parentNode = this.parentNode
        const explanationBox = parentNode.querySelector(".category-info")

        if (explanationBox.style.display === "block") {
            explanationBox.style.display = "none"
        } else {
            explanationBox.style.display = "block"

            setTimeout(() => {
                explanationBox.style.display = "none"
            }, 3500);
        }
    }

    categoryTitles.forEach(category => category.addEventListener("click", revealCategory))
    questionCon.forEach(question => question.addEventListener("click", revealQuestion))
    nameSubmit.forEach(button => button.addEventListener("click", nameChange))
    closeButton.forEach(close => close.addEventListener("click", closeZoomCon))
    pointButtons.forEach(button => button.addEventListener("click", changePoints))
    infoIcons.forEach(icon => icon.addEventListener("click", openExplanation))
}