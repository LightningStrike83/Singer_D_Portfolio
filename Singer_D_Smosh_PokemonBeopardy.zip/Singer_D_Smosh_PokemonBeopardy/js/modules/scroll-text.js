export function scrollQuestions() {
    const text = document.querySelector("#jump")

    function scrolltoInfo() {
        const infoCon = document.querySelector("#info-con")

        gsap.to(window, {duration: 1, scrollTo:{y:infoCon}})
    }

    text.addEventListener("click", scrolltoInfo)
}