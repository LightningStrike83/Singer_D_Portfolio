export function toTop() {
    const topArrow = document.querySelector("#top-arrow")

    function scrollToTop() {
        var x = window.matchMedia("(min-width: 728px)")

        if (x.matches) {
            gsap.to(window, {duration: 1, scrollTo:{y:0}})
        } else {
            gsap.to(window, {duration: 2, scrollTo:{y:0}})
        }
    }

    topArrow.addEventListener("click", scrollToTop)
}