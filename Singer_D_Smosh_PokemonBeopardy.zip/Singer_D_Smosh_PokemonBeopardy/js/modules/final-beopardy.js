export function finalBeopardy() {
    const button = document.querySelector("#fb-text")

    function activateFinalBeopardy() {
        const fjQuestionCon = document.querySelector("#fb-question-con")
        const fjCon = document.querySelector("#fb-con-con")
        const fjCategory = document.querySelector("#fb-category-con")

        fjCon.style.display = "grid"
        fjQuestionCon.style.display = "grid"

        gsap.to(window, { duration: 1, scrollTo: (0)})
    }

    button.addEventListener("click", activateFinalBeopardy)

    document.addEventListener("DOMContentLoaded", (event) => {
        gsap.registerPlugin(ScrollToPlugin)});
}