import { finalBeopardy } from "./modules/final-beopardy.js";
import { mainFunctions } from "./modules/main-functions.js";
import { scrollQuestions } from "./modules/scroll-text.js";
import { toTop } from "./modules/scroll.js";

if (document.body.dataset.page === "board") {
    mainFunctions()
    finalBeopardy()
}

if (document.body.dataset.page === "text") {
    scrollQuestions()
}

toTop()